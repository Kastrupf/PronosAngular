import { Actor } from './../Models/actor';

describe('Actor', () => {
  it('should create an instance', () => {
    expect(new Actor()).toBeTruthy();
  });
});
