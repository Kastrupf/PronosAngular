import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resultats',
  templateUrl: './resultats.component.html',
  styleUrls: ['./resultats.component.scss']
})
export class ResultatsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
