import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contest',
  templateUrl: './contest.component.html',
  styleUrls: ['./contest.component.sass']
})
export class ContestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
