export class Player {

    constructor(public id: number,
        public lastName: string,
        public firstName: string,
        public email: string,
        public subscriptionDate: Date) {
    }

}