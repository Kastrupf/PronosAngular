export class Actor {
  id: number;
  label: String;
      constructor(){}
}
